--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.19
-- Dumped by pg_dump version 11.19

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "EC_DB";
--
-- Name: EC_DB; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "EC_DB" WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'English_India.1252' LC_CTYPE = 'English_India.1252';


ALTER DATABASE "EC_DB" OWNER TO postgres;

\connect "EC_DB"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: election_candidates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.election_candidates (
    id integer NOT NULL,
    party_id integer,
    mp_seat integer,
    seat_state_id integer
);


ALTER TABLE public.election_candidates OWNER TO postgres;

--
-- Name: partymaster; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.partymaster (
    id integer NOT NULL,
    party_name character varying(250) NOT NULL,
    symbol_id integer,
    register_date timestamp without time zone
);


ALTER TABLE public.partymaster OWNER TO postgres;

--
-- Name: seatallocation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.seatallocation (
    id integer NOT NULL,
    mp_state character varying(250),
    total_seats integer
);


ALTER TABLE public.seatallocation OWNER TO postgres;

--
-- Name: symbol_master; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.symbol_master (
    id integer NOT NULL,
    symbol bytea,
    symbol_name character varying(200)
);


ALTER TABLE public.symbol_master OWNER TO postgres;

--
-- Name: votermaster; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.votermaster (
    id integer NOT NULL,
    voter_id character varying(200),
    voter_name character varying(250),
    address character varying(500),
    city character varying(100),
    voter_state_id integer,
    photo bytea,
    voter_verified character(1)
);


ALTER TABLE public.votermaster OWNER TO postgres;

--
-- Name: voting; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.voting (
    id integer NOT NULL,
    voting_date date,
    party_id integer,
    party_name character varying(200),
    symbol_id integer,
    voter_id integer
);


ALTER TABLE public.voting OWNER TO postgres;

--
-- Name: v_vote_majarity; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_vote_majarity AS
 SELECT v.party_name,
    sa.mp_state,
    count(1) AS total_vote
   FROM public.voting v,
    public.votermaster vm,
    public.symbol_master sm,
    public.seatallocation sa
  WHERE ((v.voter_id = vm.id) AND (v.symbol_id = sm.id) AND (vm.voter_state_id = sa.id))
  GROUP BY v.party_name, sa.mp_state;


ALTER TABLE public.v_vote_majarity OWNER TO postgres;

--
-- Data for Name: election_candidates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.election_candidates (id, party_id, mp_seat, seat_state_id) FROM stdin;
\.
COPY public.election_candidates (id, party_id, mp_seat, seat_state_id) FROM '$$PATH$$/2849.dat';

--
-- Data for Name: partymaster; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.partymaster (id, party_name, symbol_id, register_date) FROM stdin;
\.
COPY public.partymaster (id, party_name, symbol_id, register_date) FROM '$$PATH$$/2848.dat';

--
-- Data for Name: seatallocation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.seatallocation (id, mp_state, total_seats) FROM stdin;
\.
COPY public.seatallocation (id, mp_state, total_seats) FROM '$$PATH$$/2845.dat';

--
-- Data for Name: symbol_master; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.symbol_master (id, symbol, symbol_name) FROM stdin;
\.
COPY public.symbol_master (id, symbol, symbol_name) FROM '$$PATH$$/2846.dat';

--
-- Data for Name: votermaster; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.votermaster (id, voter_id, voter_name, address, city, voter_state_id, photo, voter_verified) FROM stdin;
\.
COPY public.votermaster (id, voter_id, voter_name, address, city, voter_state_id, photo, voter_verified) FROM '$$PATH$$/2850.dat';

--
-- Data for Name: voting; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.voting (id, voting_date, party_id, party_name, symbol_id, voter_id) FROM stdin;
\.
COPY public.voting (id, voting_date, party_id, party_name, symbol_id, voter_id) FROM '$$PATH$$/2847.dat';

--
-- Name: election_candidates election_candidates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.election_candidates
    ADD CONSTRAINT election_candidates_pkey PRIMARY KEY (id);


--
-- Name: partymaster parties_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.partymaster
    ADD CONSTRAINT parties_pkey PRIMARY KEY (id);


--
-- Name: seatallocation seatallocation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.seatallocation
    ADD CONSTRAINT seatallocation_pkey PRIMARY KEY (id);


--
-- Name: symbol_master symbol_master_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.symbol_master
    ADD CONSTRAINT symbol_master_pkey PRIMARY KEY (id);


--
-- Name: votermaster votermaster_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.votermaster
    ADD CONSTRAINT votermaster_pkey PRIMARY KEY (id);


--
-- Name: voting voting_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.voting
    ADD CONSTRAINT voting_pkey PRIMARY KEY (id);


--
-- Name: election_candidates fk_ec_party_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.election_candidates
    ADD CONSTRAINT fk_ec_party_id FOREIGN KEY (party_id) REFERENCES public.partymaster(id);


--
-- Name: election_candidates fk_ec_seat_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.election_candidates
    ADD CONSTRAINT fk_ec_seat_id FOREIGN KEY (seat_state_id) REFERENCES public.seatallocation(id);


--
-- PostgreSQL database dump complete
--

